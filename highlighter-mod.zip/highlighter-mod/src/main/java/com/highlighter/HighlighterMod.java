package com.highlighter;

import com.highlighter.config.HighlightConfig;
import net.fabricmc.api.ClientModInitializer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class HighlighterMod implements ClientModInitializer {

    public static final String MOD_ID = "highlighter";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    @Override
    public void onInitializeClient() {
        LOGGER.info("[Highlighter] Loading Highlighter mod...");
        HighlightConfig.load();
        LOGGER.info("[Highlighter] Config loaded. Highlighting is {}.", 
            HighlightConfig.INSTANCE.enabled ? "enabled" : "disabled");
    }
}
