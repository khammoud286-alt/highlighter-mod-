package com.highlighter.client;

import com.highlighter.config.HighlightConfig;
import com.terraformersmc.modmenu.api.ConfigScreenFactory;
import com.terraformersmc.modmenu.api.ModMenuApi;
import me.shedaniel.clothconfig2.api.ConfigBuilder;
import me.shedaniel.clothconfig2.api.ConfigCategory;
import me.shedaniel.clothconfig2.api.ConfigEntryBuilder;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;

public class HighlighterModMenuIntegration implements ModMenuApi {

    @Override
    public ConfigScreenFactory<?> getModConfigScreenFactory() {
        return this::buildConfigScreen;
    }

    private Screen buildConfigScreen(Screen parent) {
        HighlightConfig cfg = HighlightConfig.INSTANCE;

        ConfigBuilder builder = ConfigBuilder.create()
                .setParentScreen(parent)
                .setTitle(Text.literal("✨ Highlighter Settings"))
                .setSavingRunnable(HighlightConfig::save);

        ConfigEntryBuilder entry = builder.entryBuilder();

        // ── General ──────────────────────────────────────────────
        ConfigCategory general = builder.getOrCreateCategory(Text.literal("General"));

        general.addEntry(entry
                .startBooleanToggle(Text.literal("Enable Highlighter"), cfg.enabled)
                .setDefaultValue(true)
                .setTooltip(Text.literal("Toggle the entire mod on or off."))
                .setSaveConsumer(v -> cfg.enabled = v)
                .build());

        general.addEntry(entry
                .startIntSlider(Text.literal("Highlight Opacity"), cfg.highlightOpacity, 10, 255)
                .setDefaultValue(80)
                .setTooltip(Text.literal("How transparent the color overlay is (10 = almost invisible, 255 = solid)."))
                .setSaveConsumer(v -> cfg.highlightOpacity = v)
                .build());

        // ── Totem ────────────────────────────────────────────────
        ConfigCategory totemCat = builder.getOrCreateCategory(Text.literal("🪬 Totem of Undying"));

        totemCat.addEntry(entry
                .startBooleanToggle(Text.literal("Highlight Totem"), cfg.highlightTotem)
                .setDefaultValue(true)
                .setSaveConsumer(v -> cfg.highlightTotem = v)
                .build());

        totemCat.addEntry(entry
                .startColorField(Text.literal("Totem Color"), cfg.totemColor & 0x00FFFFFF)
                .setDefaultValue(0xFF5500)
                .setTooltip(Text.literal("RGB color for Totem of Undying highlight."))
                .setSaveConsumer(v -> cfg.totemColor = v | 0xFF000000)
                .build());

        // ── Golden Apple ─────────────────────────────────────────
        ConfigCategory gappleCat = builder.getOrCreateCategory(Text.literal("🍎 Golden Apple"));

        gappleCat.addEntry(entry
                .startBooleanToggle(Text.literal("Highlight Golden Apple"), cfg.highlightGoldenApple)
                .setDefaultValue(true)
                .setSaveConsumer(v -> cfg.highlightGoldenApple = v)
                .build());

        gappleCat.addEntry(entry
                .startColorField(Text.literal("Golden Apple Color"), cfg.goldenAppleColor & 0x00FFFFFF)
                .setDefaultValue(0xFFD700)
                .setSaveConsumer(v -> cfg.goldenAppleColor = v | 0xFF000000)
                .build());

        // ── Ender Pearl ──────────────────────────────────────────
        ConfigCategory pearlCat = builder.getOrCreateCategory(Text.literal("🟢 Ender Pearl"));

        pearlCat.addEntry(entry
                .startBooleanToggle(Text.literal("Highlight Ender Pearl"), cfg.highlightEnderPearl)
                .setDefaultValue(true)
                .setSaveConsumer(v -> cfg.highlightEnderPearl = v)
                .build());

        pearlCat.addEntry(entry
                .startColorField(Text.literal("Ender Pearl Color"), cfg.enderPearlColor & 0x00FFFFFF)
                .setDefaultValue(0x11FF11)
                .setSaveConsumer(v -> cfg.enderPearlColor = v | 0xFF000000)
                .build());

        // ── Potions ──────────────────────────────────────────────
        ConfigCategory potionCat = builder.getOrCreateCategory(Text.literal("🧪 Potions"));

        potionCat.addEntry(entry
                .startBooleanToggle(Text.literal("Highlight Potions"), cfg.highlightPotions)
                .setDefaultValue(true)
                .setSaveConsumer(v -> cfg.highlightPotions = v)
                .build());

        potionCat.addEntry(entry
                .startColorField(Text.literal("Potion Color"), cfg.potionColor & 0x00FFFFFF)
                .setDefaultValue(0x00FFFF)
                .setSaveConsumer(v -> cfg.potionColor = v | 0xFF000000)
                .build());

        // ── Swords ───────────────────────────────────────────────
        ConfigCategory swordCat = builder.getOrCreateCategory(Text.literal("⚔️ Swords"));

        swordCat.addEntry(entry
                .startBooleanToggle(Text.literal("Highlight Swords"), cfg.highlightSwords)
                .setDefaultValue(true)
                .setSaveConsumer(v -> cfg.highlightSwords = v)
                .build());

        swordCat.addEntry(entry
                .startColorField(Text.literal("Sword Color"), cfg.swordColor & 0x00FFFFFF)
                .setDefaultValue(0xFF0000)
                .setSaveConsumer(v -> cfg.swordColor = v | 0xFF000000)
                .build());

        // ── Bows ─────────────────────────────────────────────────
        ConfigCategory bowCat = builder.getOrCreateCategory(Text.literal("🏹 Bows"));

        bowCat.addEntry(entry
                .startBooleanToggle(Text.literal("Highlight Bows / Crossbows"), cfg.highlightBows)
                .setDefaultValue(true)
                .setSaveConsumer(v -> cfg.highlightBows = v)
                .build());

        bowCat.addEntry(entry
                .startColorField(Text.literal("Bow Color"), cfg.bowColor & 0x00FFFFFF)
                .setDefaultValue(0x00AAFF)
                .setSaveConsumer(v -> cfg.bowColor = v | 0xFF000000)
                .build());

        // ── Axes ─────────────────────────────────────────────────
        ConfigCategory axeCat = builder.getOrCreateCategory(Text.literal("🪓 Axes"));

        axeCat.addEntry(entry
                .startBooleanToggle(Text.literal("Highlight Axes"), cfg.highlightAxes)
                .setDefaultValue(false)
                .setSaveConsumer(v -> cfg.highlightAxes = v)
                .build());

        axeCat.addEntry(entry
                .startColorField(Text.literal("Axe Color"), cfg.axeColor & 0x00FFFFFF)
                .setDefaultValue(0x888888)
                .setSaveConsumer(v -> cfg.axeColor = v | 0xFF000000)
                .build());

        // ── Armor ────────────────────────────────────────────────
        ConfigCategory armorCat = builder.getOrCreateCategory(Text.literal("🛡️ Armor"));

        armorCat.addEntry(entry
                .startBooleanToggle(Text.literal("Highlight Armor"), cfg.highlightArmor)
                .setDefaultValue(true)
                .setSaveConsumer(v -> cfg.highlightArmor = v)
                .build());

        armorCat.addEntry(entry
                .startColorField(Text.literal("Armor Color"), cfg.armorColor & 0x00FFFFFF)
                .setDefaultValue(0x00FF88)
                .setSaveConsumer(v -> cfg.armorColor = v | 0xFF000000)
                .build());

        // ── Food ─────────────────────────────────────────────────
        ConfigCategory foodCat = builder.getOrCreateCategory(Text.literal("🍖 Food"));

        foodCat.addEntry(entry
                .startBooleanToggle(Text.literal("Highlight Food"), cfg.highlightFood)
                .setDefaultValue(false)
                .setSaveConsumer(v -> cfg.highlightFood = v)
                .build());

        foodCat.addEntry(entry
                .startColorField(Text.literal("Food Color"), cfg.foodColor & 0x00FFFFFF)
                .setDefaultValue(0xFFFF00)
                .setSaveConsumer(v -> cfg.foodColor = v | 0xFF000000)
                .build());

        // ── Enchanted (catch-all) ────────────────────────────────
        ConfigCategory enchantCat = builder.getOrCreateCategory(Text.literal("✨ Enchanted Items"));

        enchantCat.addEntry(entry
                .startBooleanToggle(Text.literal("Highlight Enchanted Items"), cfg.highlightEnchanted)
                .setDefaultValue(true)
                .setTooltip(Text.literal("Highlights any enchanted item not already highlighted by a specific rule above."))
                .setSaveConsumer(v -> cfg.highlightEnchanted = v)
                .build());

        enchantCat.addEntry(entry
                .startColorField(Text.literal("Enchanted Color"), cfg.enchantedColor & 0x00FFFFFF)
                .setDefaultValue(0x8800FF)
                .setSaveConsumer(v -> cfg.enchantedColor = v | 0xFF000000)
                .build());

        return builder.build();
    }
}
