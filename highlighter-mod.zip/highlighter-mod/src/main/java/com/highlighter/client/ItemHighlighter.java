package com.highlighter.client;

import com.highlighter.config.HighlightConfig;
import net.minecraft.item.*;
import net.minecraft.item.Item;

public class ItemHighlighter {

    /**
     * Returns the ARGB color to highlight this item slot with,
     * or -1 if no highlight should be applied.
     */
    public static int getHighlightColor(ItemStack stack) {
        if (stack == null || stack.isEmpty()) return -1;

        HighlightConfig cfg = HighlightConfig.INSTANCE;
        if (!cfg.enabled) return -1;

        Item item = stack.getItem();
        int opacity = Math.min(255, Math.max(0, cfg.highlightOpacity));

        // Totem of Undying — check first (priority)
        if (cfg.highlightTotem && item == Items.TOTEM_OF_UNDYING) {
            return withOpacity(cfg.totemColor, opacity);
        }

        // Golden Apple / Enchanted Golden Apple
        if (cfg.highlightGoldenApple && (item == Items.GOLDEN_APPLE || item == Items.ENCHANTED_GOLDEN_APPLE)) {
            return withOpacity(cfg.goldenAppleColor, opacity);
        }

        // Ender Pearl
        if (cfg.highlightEnderPearl && item == Items.ENDER_PEARL) {
            return withOpacity(cfg.enderPearlColor, opacity);
        }

        // Potions
        if (cfg.highlightPotions && (item instanceof PotionItem || item == Items.SPLASH_POTION || item == Items.LINGERING_POTION)) {
            return withOpacity(cfg.potionColor, opacity);
        }

        // Swords
        if (cfg.highlightSwords && item instanceof SwordItem) {
            return withOpacity(cfg.swordColor, opacity);
        }

        // Axes (AxeItem extends MiningToolItem)
        if (cfg.highlightAxes && item instanceof AxeItem) {
            return withOpacity(cfg.axeColor, opacity);
        }

        // Bows and Crossbows
        if (cfg.highlightBows && (item == Items.BOW || item == Items.CROSSBOW)) {
            return withOpacity(cfg.bowColor, opacity);
        }

        // Armor
        if (cfg.highlightArmor && item instanceof ArmorItem) {
            return withOpacity(cfg.armorColor, opacity);
        }

        // Food
        if (cfg.highlightFood && item.isFood()) {
            return withOpacity(cfg.foodColor, opacity);
        }

        // Enchanted items (catch-all for enchanted books etc.)
        if (cfg.highlightEnchanted && stack.hasEnchantments()) {
            return withOpacity(cfg.enchantedColor, opacity);
        }

        return -1;
    }

    private static int withOpacity(int argbColor, int opacity) {
        // Replace alpha channel
        return (argbColor & 0x00FFFFFF) | (opacity << 24);
    }
}
