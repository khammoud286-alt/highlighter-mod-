package com.highlighter.mixin;

import com.highlighter.client.ItemHighlighter;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.ingame.HandledScreen;
import net.minecraft.screen.slot.Slot;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(HandledScreen.class)
public class HandledScreenMixin {

    @Inject(
        method = "drawSlot",
        at = @At("HEAD")
    )
    private void highlighter$drawSlotHighlight(DrawContext context, Slot slot, CallbackInfo ci) {
        if (slot == null || slot.getStack() == null || slot.getStack().isEmpty()) return;

        int color = ItemHighlighter.getHighlightColor(slot.getStack());
        if (color == -1) return;

        // Draw a filled rectangle overlay over the slot (16x16 pixels)
        context.fill(slot.x, slot.y, slot.x + 16, slot.y + 16, color);
    }
}
