package com.highlighter.config;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;

import java.io.*;
import java.nio.file.Path;

public class HighlightConfig {

    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final Path CONFIG_PATH = FabricLoader.getInstance().getConfigDir().resolve("highlighter.json");

    public static HighlightConfig INSTANCE = new HighlightConfig();

    // Enable/disable entire mod
    public boolean enabled = true;

    // Totem of Undying
    public boolean highlightTotem = true;
    public int totemColor = 0xFFFF5500; // Orange

    // Enchanted items
    public boolean highlightEnchanted = true;
    public int enchantedColor = 0xFF8800FF; // Purple

    // Swords
    public boolean highlightSwords = true;
    public int swordColor = 0xFFFF0000; // Red

    // Bows & Crossbows
    public boolean highlightBows = true;
    public int bowColor = 0xFF00AAFF; // Blue

    // Axes
    public boolean highlightAxes = false;
    public int axeColor = 0xFF888888; // Gray

    // Armor
    public boolean highlightArmor = true;
    public int armorColor = 0xFF00FF88; // Green

    // Food
    public boolean highlightFood = false;
    public int foodColor = 0xFFFFFF00; // Yellow

    // Potions
    public boolean highlightPotions = true;
    public int potionColor = 0xFF00FFFF; // Cyan

    // Ender Pearl
    public boolean highlightEnderPearl = true;
    public int enderPearlColor = 0xFF11FF11; // Bright Green

    // Golden Apple
    public boolean highlightGoldenApple = true;
    public int goldenAppleColor = 0xFFFFD700; // Gold

    // Opacity/alpha of highlight overlay (0-255)
    public int highlightOpacity = 80;

    public static void load() {
        if (CONFIG_PATH.toFile().exists()) {
            try (Reader reader = new FileReader(CONFIG_PATH.toFile())) {
                INSTANCE = GSON.fromJson(reader, HighlightConfig.class);
            } catch (IOException e) {
                System.err.println("[Highlighter] Failed to load config: " + e.getMessage());
                INSTANCE = new HighlightConfig();
            }
        }
        save();
    }

    public static void save() {
        try (Writer writer = new FileWriter(CONFIG_PATH.toFile())) {
            GSON.toJson(INSTANCE, writer);
        } catch (IOException e) {
            System.err.println("[Highlighter] Failed to save config: " + e.getMessage());
        }
    }
}
