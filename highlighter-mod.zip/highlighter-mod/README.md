# ✨ Highlighter Mod — Fabric 1.20.4

Highlights items in your inventory with customizable colors depending on their type — just like the original Highlighter mod. Fully configurable via **Mod Menu**.

---

## 📦 Requirements (to build)

| Tool | Version |
|------|---------|
| Java JDK | 17 or 21 |
| Gradle | 8.6+ (wrapper included) |
| Minecraft | 1.20.4 |

---

## 🚀 How to Build the JAR

### Step 1 — Install Java 17+
Download from: https://adoptium.net/

### Step 2 — Open a terminal in this folder
```
cd highlighter-mod
```

### Step 3 — Build
**Windows:**
```
gradlew.bat build
```
**Mac/Linux:**
```
./gradlew build
```

### Step 4 — Find your JAR
```
build/libs/highlighter-1.0.0.jar
```

---

## 🎮 How to Install

1. Install **Fabric Loader** for Minecraft 1.20.4: https://fabricmc.net/use/installer/
2. Download **Fabric API**: https://modrinth.com/mod/fabric-api
3. Download **Mod Menu**: https://modrinth.com/mod/modmenu
4. Download **Cloth Config**: https://modrinth.com/mod/cloth-config
5. Drop all `.jar` files into your `.minecraft/mods/` folder
6. Drop `highlighter-1.0.0.jar` in there too
7. Launch Minecraft with Fabric profile

---

## ⚙️ Configuration

In-game → Mods button (Mod Menu) → Highlighter → Config

You can configure for each item type:
- ✅ Enable/Disable highlighting
- 🎨 Pick any RGB color
- 🔆 Set global opacity (10–255)

### Supported item types:
| Item | Default Color |
|------|--------------|
| 🪬 Totem of Undying | Orange `#FF5500` |
| 🍎 Golden Apple / Enchanted | Gold `#FFD700` |
| 🟢 Ender Pearl | Bright Green `#11FF11` |
| 🧪 Potions | Cyan `#00FFFF` |
| ⚔️ Swords | Red `#FF0000` |
| 🏹 Bows / Crossbows | Blue `#00AAFF` |
| 🪓 Axes | Gray `#888888` |
| 🛡️ Armor | Green `#00FF88` |
| 🍖 Food | Yellow `#FFFF00` |
| ✨ Enchanted (catch-all) | Purple `#8800FF` |

---

## 📁 Project Structure

```
highlighter-mod/
├── build.gradle
├── settings.gradle
├── src/main/java/com/highlighter/
│   ├── HighlighterMod.java               ← Mod entry point
│   ├── client/
│   │   ├── ItemHighlighter.java          ← Color logic per item type
│   │   └── HighlighterModMenuIntegration.java  ← Config GUI
│   ├── config/
│   │   └── HighlightConfig.java          ← JSON config file
│   └── mixin/
│       └── HandledScreenMixin.java       ← Draws color overlays on slots
└── src/main/resources/
    ├── fabric.mod.json
    └── highlighter.mixins.json
```

---

## 🪲 Troubleshooting

- **"Plugin not found"** — Make sure you have internet access when running `gradlew build` the first time (downloads Fabric Loom)
- **Java version error** — Use Java 17, not Java 8
- **Missing mod error in-game** — Make sure Fabric API, Mod Menu, and Cloth Config are all installed

---

## 📜 License

MIT — free to use, modify, and distribute.
